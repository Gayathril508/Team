package svecw.app_17b01a0508;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Team  extends AppCompatActivity {
    TextView t1,l1,ln,le,lp,m1,mn,mp,me,m2,mn2,mp2,me2,m3,mn3,mp3,me3;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.teams_display);
        t1=findViewById(R.id.text);
        l1=findViewById(R.id.teamleader);
        ln=findViewById(R.id.leadername);
        lp=findViewById(R.id.leaderphonenum);
        le=findViewById(R.id.leaderemail);
        m1=findViewById(R.id.team1);
        mn=findViewById(R.id.name1);
        mp=findViewById(R.id.phonenum1);
        me=findViewById(R.id.email1);
        m2=findViewById(R.id.team2);
        mn2=findViewById(R.id.name2);
        mp2=findViewById(R.id.phonenum2);
        me2=findViewById(R.id.email2);
        m3=findViewById(R.id.team3);
        mn3=findViewById(R.id.name3);
        mp3=findViewById(R.id.phonenum3);
        me3=findViewById(R.id.email3);

        final String  tname = getIntent().getStringExtra("team name");
        Log.v("P", tname);

        FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference databaseReference=database.getReference("NewTeam");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                DataSnapshot ds= dataSnapshot.child(tname);
                t1.setText("Team Name :"+tname);

                ln.setText("Name :"+ds.child("Team Leader").child("name").getValue().toString());
                le.setText("Name :"+ds.child("Team Leader").child("email").getValue().toString());
                lp.setText("Name :"+ds.child("Team Leader").child("phonenumber").getValue().toString());


                mn.setText("Name :"+ds.child("Team Member 1").child("name").getValue().toString());
                me.setText("Name :"+ds.child("Team Member 1").child("email").getValue().toString());
                mp.setText("Name :"+ds.child("Team Member 1").child("phonenumber").getValue().toString());

                mn2.setText("Name :"+ds.child("Team Member 2").child("name").getValue().toString());
                me2.setText("Name :"+ds.child("Team Member 2").child("email").getValue().toString());
                mp2.setText("Name :"+ds.child("Team Member 2").child("phonenumber").getValue().toString());

                mn3.setText("Name :"+ds.child("Team Member 3").child("name").getValue().toString());
                me3.setText("Name :"+ds.child("Team Member 3").child("email").getValue().toString());
                mp3.setText("Name :"+ds.child("Team Member 3").child("phonenumber").getValue().toString());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
}
