package svecw.app_17b01a0508;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_login);
       /* FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference db=database.getReference("student/profile");
        db.child("Profile_one").setValue("Bhargavi");
        db.child("last name").setValue("Gayathri");*/

    }
}
