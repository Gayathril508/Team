package svecw.app_17b01a0508;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
    TextView t1,t2;
    EditText e1,e2,e3;
    Button b1,dob;
    Spinner s1;
    RadioGroup r1;
    DatePicker datePicker1;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        t1 = findViewById(R.id.textView4);
        t2 = findViewById(R.id.textView5);
        e1 = findViewById(R.id.editText);
        e2 = findViewById(R.id.editText2);
        e3 = findViewById(R.id.editText23);
        b1 = findViewById(R.id.button);
        s1 = findViewById(R.id.spinner);
        r1 = findViewById(R.id.gender);
        dob = findViewById(R.id.selectdob);
        datePicker1 = findViewById(R.id.datePicker);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePicker1.setVisibility(view.VISIBLE);
            }
        });
        datePicker1.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {
                String selecteddob=String.valueOf(i)+"/"+String.valueOf(i1)+"/"+String.valueOf(i2);
                Log.v("svecw","date:"+selecteddob);
                e3.setText(selecteddob);
                datePicker1.setVisibility(View.GONE);
            }
        });


        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedvalue=(String)adapterView.getItemAtPosition(i);
                Log.v("svecw","value:"+selectedvalue);
                Toast.makeText(getApplicationContext(),selectedvalue,Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseDatabase database=FirebaseDatabase.getInstance();
                DatabaseReference db=database.getReference("student/profile/");
                db.child(e1.getText().toString()).child("name").setValue(e2.getText().toString());
                db.child(e1.getText().toString()).child("dob").setValue(e3.getText().toString());
                db.child(e1.getText().toString()).child("branch").setValue(s1.getSelectedItem().toString());
                int id=r1.getCheckedRadioButtonId();
                RadioButton r=findViewById(id);
                Toast.makeText(Register.this,r.getText(),Toast.LENGTH_SHORT).show();
                db.child(e1.getText().toString()).child("gender").setValue(r.getText().toString());

            }

        });
    }


}



