package svecw.app_17b01a0508;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class New_Register extends AppCompatActivity {
    EditText teamname, name1, phno1,email1,name2,email2,phno2,name3,email3,phno3,name4,email4,phno4;
    Button register;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerteam);
        teamname = findViewById(R.id.teamname);
        name1 = findViewById(R.id.name1);
        email1 = findViewById(R.id.email1);
        phno1 = findViewById(R.id.phonenum1);
        name2 = findViewById(R.id.name2);
        email2 = findViewById(R.id.email2);
        phno2 = findViewById(R.id.phonenum2);
        name3 = findViewById(R.id.name3);
        email3 = findViewById(R.id.email3);
        phno3 = findViewById(R.id.phonenum3);
        name4 = findViewById(R.id.name4);
        email4 = findViewById(R.id.email4);
        phno4 = findViewById(R.id.phonenum4);
        register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),Thankyou.class);
                FirebaseDatabase database=FirebaseDatabase.getInstance();
                DatabaseReference db =database.getReference("NewTeam/");
                db.child(teamname.getText().toString()).child("Team Leader").child("name").setValue(name1.getText().toString());
                db.child(teamname.getText().toString()).child("Team Leader").child("email").setValue(email1.getText().toString());
                db.child(teamname.getText().toString()).child("Team Leader").child("phonenumber").setValue(phno1.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 1").child("name").setValue(name2.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 1").child("email").setValue(email2.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 1").child("phonenumber").setValue(phno2.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 2").child("name").setValue(name3.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 2").child("email").setValue(email3.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 2").child("phonenumber").setValue(phno3.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 3").child("name").setValue(name4.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 3").child("email").setValue(email4.getText().toString());
                db.child(teamname.getText().toString()).child("Team Member 3").child("phonenumber").setValue(phno4.getText().toString());
                startActivity(intent);
            }
        });

    }
}
